/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_irisclassifier_free: (a: number, b: number) => void;
export const irisclassifier_get_activations: (a: number, b: number, c: number, d: number, e: number) => [number, number];
export const irisclassifier_get_class_names: (a: number) => [number, number];
export const irisclassifier_get_probabilities: (a: number, b: number, c: number, d: number, e: number) => [number, number];
export const irisclassifier_get_weights: (a: number) => [number, number];
export const irisclassifier_model_info: (a: number) => [number, number];
export const irisclassifier_new: () => [number, number, number];
export const irisclassifier_predict: (a: number, b: number, c: number, d: number, e: number) => [number, number];
export const irisclassifier_test_all: (a: number) => [number, number];
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_start: () => void;
