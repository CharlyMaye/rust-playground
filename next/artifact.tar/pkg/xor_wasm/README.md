# neural-wasm

Bibliothèque WebAssembly minimale.

## Build

```bash
./build.sh
```

## Test

Ouvrir `../www/index.html` dans un navigateur après le build.
