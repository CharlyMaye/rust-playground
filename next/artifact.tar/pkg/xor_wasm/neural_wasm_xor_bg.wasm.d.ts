/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_xornetwork_free: (a: number, b: number) => void;
export const main: () => void;
export const xornetwork_get_activations: (a: number, b: number, c: number) => [number, number];
export const xornetwork_get_class_names: (a: number) => [number, number];
export const xornetwork_get_probabilities: (a: number, b: number, c: number) => [number, number];
export const xornetwork_get_weights: (a: number) => [number, number];
export const xornetwork_model_info: (a: number) => [number, number];
export const xornetwork_new: () => [number, number, number];
export const xornetwork_predict: (a: number, b: number, c: number) => [number, number];
export const xornetwork_test_all: (a: number) => [number, number];
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_start: () => void;
